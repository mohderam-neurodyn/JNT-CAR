import { createBrowserRouter } from "react-router";
import Root from "./components/Root";
import Home from "./components/Home";
import CarListing from "./components/CarListing";
import CarDetails from "./components/CarDetails";
import Booking from "./components/Booking";
import Account from "./components/Account";
import About from "./components/About";
import NotFound from "./components/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "cars", Component: CarListing },
      { path: "cars/:id", Component: CarDetails },
      { path: "booking/:id", Component: Booking },
      { path: "account", Component: Account },
      { path: "about", Component: About },
      { path: "*", Component: NotFound },
    ],
  },
]);
