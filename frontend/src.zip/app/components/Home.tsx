import { Link } from "react-router";
import { Calendar, MapPin, Clock, Shield, Award, Headphones, Star, ChevronRight } from "lucide-react";
import { cars } from "../data/cars";

export default function Home() {
  const featuredCars = cars.slice(0, 3);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl mb-6">
                Drive Your Dreams with JNT CAR
              </h1>
              <p className="text-xl mb-8 text-blue-100">
                Book self-drive cars at affordable prices. Experience freedom, flexibility, and the joy of driving.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link
                  to="/cars"
                  className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors inline-flex items-center gap-2"
                >
                  Browse Cars
                  <ChevronRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/about"
                  className="bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-800 transition-colors border-2 border-white"
                >
                  Learn More
                </Link>
              </div>
            </div>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1760561149879-d2dcda994a42?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjYXIlMjBkcml2aW5nJTIwcm9hZHxlbnwxfHx8fDE3NzQ3MTAzOTZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Car on road"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Quick Search */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12">
        <div className="bg-white rounded-xl shadow-xl p-6 md:p-8">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg">
              <MapPin className="w-6 h-6 text-blue-600" />
              <div className="flex-1">
                <label className="text-sm text-gray-600">Location</label>
                <select className="w-full border-none outline-none font-medium">
                  <option>Mumbai</option>
                  <option>Delhi</option>
                  <option>Bangalore</option>
                  <option>Pune</option>
                </select>
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg">
              <Calendar className="w-6 h-6 text-blue-600" />
              <div className="flex-1">
                <label className="text-sm text-gray-600">Start Date</label>
                <input
                  type="date"
                  className="w-full border-none outline-none font-medium"
                  defaultValue="2026-03-29"
                />
              </div>
            </div>
            <div className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg">
              <Clock className="w-6 h-6 text-blue-600" />
              <div className="flex-1">
                <label className="text-sm text-gray-600">Duration</label>
                <select className="w-full border-none outline-none font-medium">
                  <option>1 Day</option>
                  <option>2 Days</option>
                  <option>3 Days</option>
                  <option>1 Week</option>
                </select>
              </div>
            </div>
          </div>
          <Link
            to="/cars"
            className="w-full bg-blue-600 text-white py-3 rounded-lg mt-6 font-semibold hover:bg-blue-700 transition-colors block text-center"
          >
            Search Cars
          </Link>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl mb-4">Why Choose JNT CAR?</h2>
            <p className="text-gray-600 text-lg">Experience the best in self-drive car rentals</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl mb-3">Fully Insured</h3>
              <p className="text-gray-600">
                All our vehicles are comprehensively insured for your peace of mind and safety.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl mb-3">Best Prices</h3>
              <p className="text-gray-600">
                Get the most competitive rates in the market with no hidden charges.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Headphones className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl mb-3">24/7 Support</h3>
              <p className="text-gray-600">
                Round-the-clock customer support to assist you whenever you need help.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Cars */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-12">
            <div>
              <h2 className="text-3xl md:text-4xl mb-2">Featured Cars</h2>
              <p className="text-gray-600 text-lg">Popular choices for your journey</p>
            </div>
            <Link
              to="/cars"
              className="text-blue-600 hover:text-blue-700 font-semibold flex items-center gap-2"
            >
              View All
              <ChevronRight className="w-5 h-5" />
            </Link>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {featuredCars.map((car) => (
              <Link
                key={car.id}
                to={`/cars/${car.id}`}
                className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow overflow-hidden"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={car.image}
                    alt={car.name}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl">{car.name}</h3>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                      <span className="font-semibold">{car.rating}</span>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4">{car.brand} • {car.category}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-2xl text-blue-600">₹{car.pricePerDay}</span>
                      <span className="text-gray-600">/day</span>
                    </div>
                    <span className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                      Book Now
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl mb-4">How It Works</h2>
            <p className="text-gray-600 text-lg">Book your car in 3 simple steps</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                1
              </div>
              <h3 className="text-xl mb-3">Choose Your Car</h3>
              <p className="text-gray-600">
                Browse our wide selection of cars and pick the one that suits your needs.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                2
              </div>
              <h3 className="text-xl mb-3">Book & Pay</h3>
              <p className="text-gray-600">
                Select your dates, complete the booking, and make a secure payment online.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-blue-600 text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-2xl">
                3
              </div>
              <h3 className="text-xl mb-3">Hit The Road</h3>
              <p className="text-gray-600">
                Pick up your car and enjoy the freedom of self-drive at your convenience.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl mb-4">Ready to Start Your Journey?</h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of happy customers who trust JNT CAR for their self-drive needs.
          </p>
          <Link
            to="/cars"
            className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors inline-flex items-center gap-2"
          >
            Book Your Car Now
            <ChevronRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
}
