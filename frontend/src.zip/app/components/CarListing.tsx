import { useState } from "react";
import { Link } from "react-router";
import { Filter, Star, Users, Fuel, Settings } from "lucide-react";
import { cars, categories, transmissions, fuelTypes, locations } from "../data/cars";

export default function CarListing() {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [selectedTransmission, setSelectedTransmission] = useState("All");
  const [selectedFuel, setSelectedFuel] = useState("All");
  const [selectedLocation, setSelectedLocation] = useState("All");
  const [sortBy, setSortBy] = useState("featured");

  const filteredCars = cars.filter((car) => {
    if (selectedCategory !== "All" && car.category !== selectedCategory) return false;
    if (selectedTransmission !== "All" && car.transmission !== selectedTransmission) return false;
    if (selectedFuel !== "All" && car.fuel !== selectedFuel) return false;
    if (selectedLocation !== "All" && car.location !== selectedLocation) return false;
    return true;
  });

  const sortedCars = [...filteredCars].sort((a, b) => {
    if (sortBy === "price-low") return a.pricePerDay - b.pricePerDay;
    if (sortBy === "price-high") return b.pricePerDay - a.pricePerDay;
    if (sortBy === "rating") return b.rating - a.rating;
    return 0;
  });

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl mb-2">Browse Cars</h1>
          <p className="text-gray-600 text-lg">
            Choose from our wide selection of self-drive cars
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
              <div className="flex items-center gap-2 mb-6">
                <Filter className="w-5 h-5 text-blue-600" />
                <h2 className="text-xl">Filters</h2>
              </div>

              {/* Location Filter */}
              <div className="mb-6">
                <label className="block font-semibold mb-3">Location</label>
                <select
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                >
                  <option value="All">All Locations</option>
                  {locations.map((location) => (
                    <option key={location} value={location}>
                      {location}
                    </option>
                  ))}
                </select>
              </div>

              {/* Category Filter */}
              <div className="mb-6">
                <label className="block font-semibold mb-3">Category</label>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <label
                      key={category}
                      className="flex items-center gap-2 cursor-pointer"
                    >
                      <input
                        type="radio"
                        name="category"
                        value={category}
                        checked={selectedCategory === category}
                        onChange={(e) => setSelectedCategory(e.target.value)}
                        className="w-4 h-4 text-blue-600"
                      />
                      <span>{category}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Transmission Filter */}
              <div className="mb-6">
                <label className="block font-semibold mb-3">Transmission</label>
                <div className="space-y-2">
                  {transmissions.map((transmission) => (
                    <label
                      key={transmission}
                      className="flex items-center gap-2 cursor-pointer"
                    >
                      <input
                        type="radio"
                        name="transmission"
                        value={transmission}
                        checked={selectedTransmission === transmission}
                        onChange={(e) => setSelectedTransmission(e.target.value)}
                        className="w-4 h-4 text-blue-600"
                      />
                      <span>{transmission}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Fuel Filter */}
              <div className="mb-6">
                <label className="block font-semibold mb-3">Fuel Type</label>
                <div className="space-y-2">
                  {fuelTypes.map((fuel) => (
                    <label
                      key={fuel}
                      className="flex items-center gap-2 cursor-pointer"
                    >
                      <input
                        type="radio"
                        name="fuel"
                        value={fuel}
                        checked={selectedFuel === fuel}
                        onChange={(e) => setSelectedFuel(e.target.value)}
                        className="w-4 h-4 text-blue-600"
                      />
                      <span>{fuel}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Clear Filters */}
              <button
                onClick={() => {
                  setSelectedCategory("All");
                  setSelectedTransmission("All");
                  setSelectedFuel("All");
                  setSelectedLocation("All");
                }}
                className="w-full bg-gray-100 text-gray-700 py-2 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Clear All Filters
              </button>
            </div>
          </div>

          {/* Cars Grid */}
          <div className="lg:col-span-3">
            {/* Sort and Count */}
            <div className="bg-white rounded-xl shadow-sm p-4 mb-6 flex flex-wrap items-center justify-between gap-4">
              <p className="text-gray-600">
                Showing <span className="font-semibold">{sortedCars.length}</span> cars
              </p>
              <div className="flex items-center gap-2">
                <label className="text-gray-600">Sort by:</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                >
                  <option value="featured">Featured</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
              </div>
            </div>

            {/* Cars List */}
            {sortedCars.length === 0 ? (
              <div className="bg-white rounded-xl shadow-sm p-12 text-center">
                <p className="text-gray-600 text-lg">
                  No cars found matching your filters. Please try different options.
                </p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {sortedCars.map((car) => (
                  <Link
                    key={car.id}
                    to={`/cars/${car.id}`}
                    className="bg-white rounded-xl shadow-sm hover:shadow-lg transition-shadow overflow-hidden"
                  >
                    <div className="aspect-video overflow-hidden">
                      <img
                        src={car.image}
                        alt={car.name}
                        className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-xl">{car.name}</h3>
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                          <span className="font-semibold">{car.rating}</span>
                        </div>
                      </div>
                      <p className="text-gray-600 mb-4">
                        {car.brand} • {car.category}
                      </p>

                      {/* Car Features */}
                      <div className="grid grid-cols-3 gap-2 mb-4 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Users className="w-4 h-4" />
                          <span>{car.seats} Seats</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Settings className="w-4 h-4" />
                          <span>{car.transmission}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Fuel className="w-4 h-4" />
                          <span>{car.fuel}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between border-t pt-4">
                        <div>
                          <div className="text-2xl text-blue-600">
                            ₹{car.pricePerDay}
                            <span className="text-sm text-gray-600">/day</span>
                          </div>
                          <div className="text-sm text-gray-500">
                            ₹{car.pricePerHour}/hr
                          </div>
                        </div>
                        <span className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                          View Details
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
