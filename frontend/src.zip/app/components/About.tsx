import { Shield, Award, Users, Target, Heart, TrendingUp } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl mb-6">About JNT CAR</h1>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            India's leading self-drive car rental platform, empowering millions of travelers
            with the freedom to explore at their own pace.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  Founded in 2018, JNT CAR started with a simple vision: to make car rentals
                  accessible, affordable, and hassle-free for everyone. We believed that the joy
                  of driving shouldn't be limited by ownership.
                </p>
                <p>
                  Today, we've grown to become one of India's most trusted self-drive car rental
                  platforms, serving customers across major cities with a diverse fleet of
                  well-maintained vehicles.
                </p>
                <p>
                  Our commitment to quality, transparency, and customer satisfaction has helped
                  us build lasting relationships with thousands of satisfied customers who trust
                  us for their travel needs.
                </p>
              </div>
            </div>
            <div>
              <img
                src="https://images.unsplash.com/photo-1601236955994-f27f70bb7f6c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoYXBweSUyMHBlb3BsZSUyMGRyaXZpbmclMjBjYXJ8ZW58MXx8fHwxNzc0NzEwMzk2fDA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Happy customers"
                className="rounded-xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl mb-4">Our Values</h2>
            <p className="text-gray-600 text-lg">The principles that guide everything we do</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl mb-3">Trust & Safety</h3>
              <p className="text-gray-600">
                We prioritize your safety with fully insured vehicles and verified customers,
                ensuring peace of mind on every journey.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Heart className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl mb-3">Customer First</h3>
              <p className="text-gray-600">
                Your satisfaction is our priority. We go the extra mile to ensure every rental
                experience exceeds expectations.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl mb-3">Innovation</h3>
              <p className="text-gray-600">
                We continuously improve our platform and services, embracing technology to make
                car rentals easier and more convenient.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl mb-4">JNT CAR by Numbers</h2>
            <p className="text-gray-600 text-lg">Our journey in statistics</p>
          </div>
          <div className="grid md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl md:text-5xl text-blue-600 mb-2">50K+</div>
              <p className="text-gray-600">Happy Customers</p>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl text-blue-600 mb-2">500+</div>
              <p className="text-gray-600">Cars Available</p>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl text-blue-600 mb-2">15+</div>
              <p className="text-gray-600">Cities Covered</p>
            </div>
            <div className="text-center">
              <div className="text-4xl md:text-5xl text-blue-600 mb-2">4.8</div>
              <p className="text-gray-600">Average Rating</p>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <Target className="w-8 h-8 text-blue-600" />
                <h3 className="text-2xl">Our Mission</h3>
              </div>
              <p className="text-gray-700 leading-relaxed">
                To democratize access to personal mobility by providing affordable, convenient,
                and reliable self-drive car rental services across India. We aim to empower
                people with the freedom to travel on their terms, creating memorable journeys
                and experiences.
              </p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <Award className="w-8 h-8 text-blue-600" />
                <h3 className="text-2xl">Our Vision</h3>
              </div>
              <p className="text-gray-700 leading-relaxed">
                To become India's most loved and trusted mobility partner, setting new standards
                in customer service and innovation. We envision a future where self-drive
                rentals are the first choice for travelers seeking flexibility, convenience, and
                value.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-blue-600 text-white rounded-2xl p-12">
            <Users className="w-16 h-16 mx-auto mb-6" />
            <h2 className="text-3xl md:text-4xl mb-4">Join Our Team</h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              We're always looking for passionate individuals who want to revolutionize the car
              rental industry. Be part of something amazing!
            </p>
            <button className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
              View Careers
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
