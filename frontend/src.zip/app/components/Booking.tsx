import { useState } from "react";
import { useParams, useNavigate, Link } from "react-router";
import { CheckCircle, ChevronLeft, CreditCard, Wallet } from "lucide-react";
import { cars } from "../data/cars";

export default function Booking() {
  const { id } = useParams();
  const navigate = useNavigate();
  const car = cars.find((c) => c.id === id);
  const [step, setStep] = useState(1);
  const [bookingComplete, setBookingComplete] = useState(false);

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    licenseNumber: "",
    address: "",
    paymentMethod: "card",
  });

  if (!car) {
    return (
      <div className="min-h-screen bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl mb-4">Car Not Found</h1>
          <Link to="/cars" className="text-blue-600 hover:underline">
            Back to Browse Cars
          </Link>
        </div>
      </div>
    );
  }

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
    } else {
      setBookingComplete(true);
    }
  };

  if (bookingComplete) {
    return (
      <div className="min-h-screen bg-gray-50 py-20">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white rounded-xl shadow-sm p-12">
            <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-green-600" />
            </div>
            <h1 className="text-3xl mb-4">Booking Confirmed!</h1>
            <p className="text-gray-600 text-lg mb-2">
              Your booking for <span className="font-semibold">{car.name}</span> has been confirmed.
            </p>
            <p className="text-gray-600 mb-8">
              Booking ID: <span className="font-semibold">#JNT{Math.floor(Math.random() * 100000)}</span>
            </p>
            <div className="bg-blue-50 rounded-lg p-6 mb-8 text-left">
              <h3 className="font-semibold mb-4">Next Steps:</h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <span>You will receive a confirmation email shortly</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <span>Bring your driving license and Aadhar card at pickup</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <span>Our team will contact you 24 hours before pickup</span>
                </li>
              </ul>
            </div>
            <div className="flex flex-wrap gap-4 justify-center">
              <Link
                to="/account"
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                View My Bookings
              </Link>
              <Link
                to="/cars"
                className="bg-gray-100 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Browse More Cars
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ChevronLeft className="w-5 h-5" />
          Back
        </button>

        {/* Progress Steps */}
        <div className="mb-8">
          <div className="flex items-center justify-center gap-4">
            {[1, 2, 3].map((s) => (
              <div key={s} className="flex items-center gap-2">
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                    step >= s
                      ? "bg-blue-600 text-white"
                      : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {s}
                </div>
                <span className={step >= s ? "text-blue-600" : "text-gray-600"}>
                  {s === 1 ? "Details" : s === 2 ? "Review" : "Payment"}
                </span>
                {s < 3 && <div className="w-12 h-0.5 bg-gray-300 ml-2" />}
              </div>
            ))}
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Booking Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-6">
              <form onSubmit={handleSubmit}>
                {step === 1 && (
                  <div>
                    <h2 className="text-2xl mb-6">Personal Details</h2>
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-semibold mb-2">
                          First Name *
                        </label>
                        <input
                          type="text"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleInputChange}
                          required
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold mb-2">
                          Last Name *
                        </label>
                        <input
                          type="text"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleInputChange}
                          required
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold mb-2">
                          Email *
                        </label>
                        <input
                          type="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          required
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-semibold mb-2">
                          Phone Number *
                        </label>
                        <input
                          type="tel"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          required
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-sm font-semibold mb-2">
                          Driving License Number *
                        </label>
                        <input
                          type="text"
                          name="licenseNumber"
                          value={formData.licenseNumber}
                          onChange={handleInputChange}
                          required
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-sm font-semibold mb-2">
                          Address *
                        </label>
                        <textarea
                          name="address"
                          value={formData.address}
                          onChange={handleInputChange}
                          required
                          rows={3}
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {step === 2 && (
                  <div>
                    <h2 className="text-2xl mb-6">Review Booking</h2>
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-semibold mb-3">Personal Information</h3>
                        <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                          <p>
                            <span className="text-gray-600">Name:</span>{" "}
                            {formData.firstName} {formData.lastName}
                          </p>
                          <p>
                            <span className="text-gray-600">Email:</span> {formData.email}
                          </p>
                          <p>
                            <span className="text-gray-600">Phone:</span> {formData.phone}
                          </p>
                          <p>
                            <span className="text-gray-600">License:</span>{" "}
                            {formData.licenseNumber}
                          </p>
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold mb-3">Rental Details</h3>
                        <div className="bg-gray-50 rounded-lg p-4 space-y-2">
                          <p>
                            <span className="text-gray-600">Pickup:</span> March 29, 2026 at 10:00 AM
                          </p>
                          <p>
                            <span className="text-gray-600">Return:</span> March 30, 2026 at 10:00 AM
                          </p>
                          <p>
                            <span className="text-gray-600">Location:</span> {car.location} - Hub 1
                          </p>
                          <p>
                            <span className="text-gray-600">Duration:</span> 1 Day
                          </p>
                        </div>
                      </div>
                      <div className="bg-blue-50 rounded-lg p-4">
                        <label className="flex items-start gap-3 cursor-pointer">
                          <input
                            type="checkbox"
                            required
                            className="mt-1"
                          />
                          <span className="text-sm">
                            I agree to the terms and conditions, cancellation policy, and understand
                            that a refundable security deposit will be required at pickup.
                          </span>
                        </label>
                      </div>
                    </div>
                  </div>
                )}

                {step === 3 && (
                  <div>
                    <h2 className="text-2xl mb-6">Payment Method</h2>
                    <div className="space-y-4 mb-6">
                      <label className="flex items-center gap-3 p-4 border-2 border-gray-300 rounded-lg cursor-pointer hover:border-blue-600 transition-colors">
                        <input
                          type="radio"
                          name="paymentMethod"
                          value="card"
                          checked={formData.paymentMethod === "card"}
                          onChange={handleInputChange}
                          className="w-5 h-5"
                        />
                        <CreditCard className="w-6 h-6 text-blue-600" />
                        <div className="flex-1">
                          <p className="font-semibold">Credit/Debit Card</p>
                          <p className="text-sm text-gray-600">Pay securely with your card</p>
                        </div>
                      </label>
                      <label className="flex items-center gap-3 p-4 border-2 border-gray-300 rounded-lg cursor-pointer hover:border-blue-600 transition-colors">
                        <input
                          type="radio"
                          name="paymentMethod"
                          value="upi"
                          checked={formData.paymentMethod === "upi"}
                          onChange={handleInputChange}
                          className="w-5 h-5"
                        />
                        <Wallet className="w-6 h-6 text-blue-600" />
                        <div className="flex-1">
                          <p className="font-semibold">UPI</p>
                          <p className="text-sm text-gray-600">
                            Pay using Google Pay, PhonePe, Paytm, etc.
                          </p>
                        </div>
                      </label>
                    </div>

                    {formData.paymentMethod === "card" && (
                      <div className="space-y-4">
                        <div>
                          <label className="block text-sm font-semibold mb-2">
                            Card Number
                          </label>
                          <input
                            type="text"
                            placeholder="1234 5678 9012 3456"
                            required
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-semibold mb-2">
                              Expiry Date
                            </label>
                            <input
                              type="text"
                              placeholder="MM/YY"
                              required
                              className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold mb-2">CVV</label>
                            <input
                              type="text"
                              placeholder="123"
                              required
                              className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {formData.paymentMethod === "upi" && (
                      <div>
                        <label className="block text-sm font-semibold mb-2">UPI ID</label>
                        <input
                          type="text"
                          placeholder="yourname@upi"
                          required
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                        />
                      </div>
                    )}
                  </div>
                )}

                {/* Navigation Buttons */}
                <div className="flex gap-4 mt-8">
                  {step > 1 && (
                    <button
                      type="button"
                      onClick={() => setStep(step - 1)}
                      className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      Back
                    </button>
                  )}
                  <button
                    type="submit"
                    className="flex-1 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    {step === 3 ? "Complete Booking" : "Continue"}
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
              <h3 className="text-xl mb-4">Order Summary</h3>
              <div className="mb-4">
                <img
                  src={car.image}
                  alt={car.name}
                  className="w-full rounded-lg mb-3"
                />
                <h4 className="font-semibold">{car.name}</h4>
                <p className="text-gray-600 text-sm">
                  {car.brand} • {car.category}
                </p>
              </div>
              <div className="border-t pt-4 space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">1 Day Rental</span>
                  <span className="font-semibold">₹{car.pricePerDay}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Insurance</span>
                  <span className="font-semibold">Included</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">GST (18%)</span>
                  <span className="font-semibold">
                    ₹{Math.round(car.pricePerDay * 0.18)}
                  </span>
                </div>
                <div className="flex justify-between pt-3 border-t">
                  <span className="font-semibold">Total Amount</span>
                  <span className="text-xl text-blue-600">
                    ₹{Math.round(car.pricePerDay * 1.18)}
                  </span>
                </div>
              </div>
              <div className="mt-4 bg-yellow-50 rounded-lg p-3 text-sm text-gray-700">
                Security deposit of ₹{car.pricePerDay * 2} will be blocked on your card
                and refunded after car return.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
