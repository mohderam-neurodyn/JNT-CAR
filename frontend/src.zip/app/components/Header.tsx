import { Link, useLocation } from "react-router";
import { Car, User, Menu, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Car className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-gray-900">JNT CAR</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link
              to="/"
              className={`${
                isActive("/")
                  ? "text-blue-600"
                  : "text-gray-700 hover:text-blue-600"
              } transition-colors`}
            >
              Home
            </Link>
            <Link
              to="/cars"
              className={`${
                isActive("/cars")
                  ? "text-blue-600"
                  : "text-gray-700 hover:text-blue-600"
              } transition-colors`}
            >
              Browse Cars
            </Link>
            <Link
              to="/about"
              className={`${
                isActive("/about")
                  ? "text-blue-600"
                  : "text-gray-700 hover:text-blue-600"
              } transition-colors`}
            >
              About Us
            </Link>
            <Link
              to="/account"
              className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <User className="w-4 h-4" />
              Account
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-4">
            <Link
              to="/"
              className={`block ${
                isActive("/") ? "text-blue-600" : "text-gray-700"
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              to="/cars"
              className={`block ${
                isActive("/cars") ? "text-blue-600" : "text-gray-700"
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              Browse Cars
            </Link>
            <Link
              to="/about"
              className={`block ${
                isActive("/about") ? "text-blue-600" : "text-gray-700"
              }`}
              onClick={() => setMobileMenuOpen(false)}
            >
              About Us
            </Link>
            <Link
              to="/account"
              className="block bg-blue-600 text-white px-4 py-2 rounded-lg text-center"
              onClick={() => setMobileMenuOpen(false)}
            >
              Account
            </Link>
          </div>
        )}
      </nav>
    </header>
  );
}
