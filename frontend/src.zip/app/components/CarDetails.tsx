import { useParams, Link, useNavigate } from "react-router";
import { Star, Users, Fuel, Settings, MapPin, Shield, CheckCircle, ChevronLeft } from "lucide-react";
import { cars } from "../data/cars";

export default function CarDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const car = cars.find((c) => c.id === id);

  if (!car) {
    return (
      <div className="min-h-screen bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-3xl mb-4">Car Not Found</h1>
          <Link to="/cars" className="text-blue-600 hover:underline">
            Back to Browse Cars
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6"
        >
          <ChevronLeft className="w-5 h-5" />
          Back
        </button>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Car Details */}
          <div className="lg:col-span-2">
            {/* Car Image */}
            <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-6">
              <img
                src={car.image}
                alt={car.name}
                className="w-full aspect-video object-cover"
              />
            </div>

            {/* Car Info */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h1 className="text-3xl mb-2">{car.name}</h1>
                  <p className="text-gray-600 text-lg">
                    {car.brand} • {car.category}
                  </p>
                </div>
                <div className="flex items-center gap-2 bg-yellow-50 px-3 py-2 rounded-lg">
                  <Star className="w-5 h-5 fill-yellow-400 text-yellow-400" />
                  <span className="font-semibold">{car.rating}</span>
                  <span className="text-gray-600">({car.reviews} reviews)</span>
                </div>
              </div>

              {/* Specifications */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-6 border-y">
                <div className="text-center">
                  <Users className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Seats</p>
                  <p className="font-semibold">{car.seats}</p>
                </div>
                <div className="text-center">
                  <Settings className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Transmission</p>
                  <p className="font-semibold">{car.transmission}</p>
                </div>
                <div className="text-center">
                  <Fuel className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Fuel Type</p>
                  <p className="font-semibold">{car.fuel}</p>
                </div>
                <div className="text-center">
                  <MapPin className="w-6 h-6 text-blue-600 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Location</p>
                  <p className="font-semibold">{car.location}</p>
                </div>
              </div>

              {/* Features */}
              <div className="mt-6">
                <h2 className="text-xl mb-4">Features</h2>
                <div className="grid grid-cols-2 gap-3">
                  {car.features.map((feature, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Additional Info */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl mb-4">Important Information</h2>
              <div className="space-y-4 text-gray-600">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-gray-900">Insurance Included</p>
                    <p className="text-sm">
                      Comprehensive insurance coverage included in the rental price
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-gray-900">Documents Required</p>
                    <p className="text-sm">
                      Valid Driving License, Aadhar Card, and a refundable security deposit
                    </p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <Fuel className="w-5 h-5 text-blue-600 mt-1" />
                  <div>
                    <p className="font-semibold text-gray-900">Fuel Policy</p>
                    <p className="text-sm">
                      Car will be delivered with full tank. Return with full tank or pay for fuel
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Booking Card */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-24">
              <div className="mb-6">
                <div className="flex items-baseline gap-2 mb-2">
                  <span className="text-3xl text-blue-600">₹{car.pricePerDay}</span>
                  <span className="text-gray-600">/day</span>
                </div>
                <p className="text-gray-600">₹{car.pricePerHour}/hour</p>
              </div>

              {/* Booking Form */}
              <div className="space-y-4 mb-6">
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Pickup Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                    defaultValue="2026-03-29T10:00"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Return Date & Time
                  </label>
                  <input
                    type="datetime-local"
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600"
                    defaultValue="2026-03-30T10:00"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2">
                    Pickup Location
                  </label>
                  <select className="w-full border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-blue-600">
                    <option>{car.location} - Hub 1</option>
                    <option>{car.location} - Hub 2</option>
                    <option>{car.location} - Airport</option>
                  </select>
                </div>
              </div>

              {/* Price Breakdown */}
              <div className="bg-gray-50 rounded-lg p-4 mb-6 space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-600">1 Day Rental</span>
                  <span className="font-semibold">₹{car.pricePerDay}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Insurance</span>
                  <span className="font-semibold">Included</span>
                </div>
                <div className="flex justify-between pt-2 border-t">
                  <span className="font-semibold">Total</span>
                  <span className="font-semibold text-blue-600">₹{car.pricePerDay}</span>
                </div>
              </div>

              <Link
                to={`/booking/${car.id}`}
                className="block w-full bg-blue-600 text-white text-center py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
              >
                Proceed to Book
              </Link>

              <p className="text-xs text-gray-500 text-center mt-4">
                Free cancellation up to 24 hours before pickup
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
